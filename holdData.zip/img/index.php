<?php 
 header("Location: http://localhost/holddata/");
