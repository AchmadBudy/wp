<?php
session_start();

if (!isset($_SESSION["login"])) {
    header("Location: index.php");
    exit;
}
// var_dump($_GET);
require 'function.php';

if (!isset($_GET["product"])) {
    header("Location: http://localhost/holddata/tambah/dashboard.php");
}

$pro = query("SELECT * FROM product WHERE id = " . $_GET["product"])[0];
// var_dump($pro);


// cek apakah tombol submit sudah ditekan atau belum
if (isset($_POST["ubah"])) {

    // cek apakah data berhasil diubah atau tidak
    if (ubah($_POST) > 0) {
        echo "
			<script>
				alert('data berhasil diubah!');
				document.location.href = 'dashboard.php';
			</script>
		";
    } else {
        echo "
			<script>
				alert('data gagal diubah!');
				document.location.href = 'dashboard.php';
			</script>
		";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous" />
    <link href="https://fonts.googleapis.com/css2?family=Fredoka+One&display=swap" rel="stylesheet" />

    <style>
        .titled {
            font-family: "Fredoka One", cursive;
        }
    </style>

    <link rel="icon" href="../img/logoWB.png" />
    <title>AchticToserba</title>
</head>

<body>
    <nav class="navbar navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand titled" href="dashboard.php">
                <img src="../img/logoWB.png" width="30" height="30" class="d-inline-block align-top rounded" alt="" loading="lazy" />
                AchticToserba
            </a>
        </div>
    </nav>


    <div class="sale-content mt-5">
        <div class="container">
            <div class="row row-cols-1 row-cols-md-3">
                <div class="col mb-4">
                    <div class="card kotak">
                        <div class="card-body">
                            <form enctype="multipart/form-data" method="POST" action="">
                                <h3>Test pak</h3>
                                <input type="hidden" value="<?= $pro["id"] ?>" name="id">
                                <input type="hidden" value="<?= $pro["id"] ?>" name="gambarLama">
                                <div class="form-group">
                                    <label for="nama">nama produk</label>
                                    <input type="text" class="form-control" id="nama" name="nama" value="<?= $pro["name"] ?>">
                                </div>
                                <div class="form-group">
                                    <label for="nama">harga</label>
                                    <input type="number" class="form-control" id="nama" name="harga" value="<?= $pro["price"] ?>">
                                </div>
                                <div class="form-group">
                                    <label for="nama">Stock</label>
                                    <input type="number" class="form-control" id="nama" name="stock" value="<?= $pro["stock"] ?>">
                                </div>
                                <div class="form-group">
                                    <label for="nama">Sold</label>
                                    <input type="number" class="form-control" id="nama" name="sold" value="<?= $pro["sold"] ?>">
                                </div>
                                <div class="form-group">
                                    <label for="nama">Wa</label>
                                    <input type="text" class="form-control" id="nama" name="wa" value="<?= $pro["wa"] ?>">
                                </div>
                                <div class="form-group">
                                    <label for="nama">Shopee</label>
                                    <input type="text" class="form-control" id="nama" name="shopee" value="<?= $pro["shopee"] ?>">
                                </div>
                                <div class="form-group">
                                    <label for="nama">gambar</label>
                                    <img src="../img/<?= $pro["image"] ?>" width="60">
                                    <input type="file" class="form-control" id="nama" name="gambar">
                                </div>
                                <div class="form-group">
                                    <label for="desc">desc</label>
                                    <textarea id="desc" name="desc" rows="4" cols="50" class="form-control"><?= $pro["desk"] ?></textarea>
                                </div>
                                <button type="submit" class="btn btn-primary" name="ubah">Submit</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <footer class="footer mt-auto py-3 bg-light">
        <div class="container">
            <span class="text-muted">Place sticky footer content here.</span>
        </div>
    </footer>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
</body>

</html>