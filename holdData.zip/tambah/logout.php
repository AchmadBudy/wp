<?php
session_start();
$_SESSION = [];
session_unset();
session_destroy();

setcookie('cf_uid', '', time() - 36000);

header("Location: index.php");
exit;
