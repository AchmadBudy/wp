<?php
session_start();

if (!isset($_SESSION["login"])) {
    header("Location: index.php");
    exit;
}


require 'function.php';

$product = query("SELECT * FROM product");

if (isset($_POST["milih"])) {
    if (isset($_POST["tambah"])) {
        $valueAwal = query("SELECT stock FROM product WHERE id = " . $_POST["milih"])[0]["stock"];
        // var_dump($valueAwal);

        $check = stock("UPDATE product SET stock = " . ($valueAwal + $_POST["isinyaTambah"]) . " WHERE product.id = " . $_POST["milih"]);

        if ($check == 1) {
            echo "<script>
            alert('data berhasil ditambahkan!');
            document.location.href = 'dashboard.php';
        </script>";
        } else {
            echo "<script>
            alert('data gagal ditambahkan!');
            document.location.href = 'dashboard.php';
        </script>";
        }
    }

    if (isset($_POST["kurang"])) {
        $valueStock = query("SELECT stock FROM product WHERE id = " . $_POST["milih"])[0]["stock"];
        $valueSold = query("SELECT sold FROM product WHERE id = " . $_POST["milih"])[0]["sold"];
        // var_dump($valueAwal);

        $check = stock("UPDATE product SET 
        stock = " . ($valueStock - $_POST["isinyaKurang"]) . ", 
        sold = " . ($valueSold + $_POST["isinyaKurang"]) . " 
        WHERE product.id = " . $_POST["milih"]);

        if ($check == 1) {
            echo "<script>
            alert('data berhasil ditambahkan!');
            document.location.href = 'dashboard.php';
        </script>";
        } else {
            echo "<script>
            alert('data gagal ditambahkan!');
            document.location.href = 'dashboard.php';
        </script>";
        }
    }
    // var_dump($_POST);
}



if (isset($_POST["pilih"])) {
    if ($_POST["pilih"] == "hapus") {
        if (hapus($_POST["id"]) > 0) {
            echo "
                <script>
                    alert('data berhasil dihapus!');
                    document.location.href = 'dashboard.php';
                </script>
            ";
        } else {
            echo "
                <script>
                    alert('data gagal dihapus!');
                    document.location.href = 'dashboard.php';
                </script>
            ";
        }
    } else {
        header("Location: http://localhost/holddata/tambah/info.php?product=" . $_POST["id"]);
        echo " hi";
    }
}
// var_dump($product);
// var_dump($mahasiswa);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous" />
    <link href="https://fonts.googleapis.com/css2?family=Fredoka+One&display=swap" rel="stylesheet" />

    <style>
        .titled {
            font-family: "Fredoka One", cursive;
        }
    </style>

    <link rel="icon" href="../img/logoWB.png" />
    <title>AchticToserba</title>
</head>

<body>
    <nav class="navbar navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand titled" href="#">
                <img src="../img/logoWB.png" width="30" height="30" class="d-inline-block align-top rounded" alt="" loading="lazy" />
                AchticToserba
            </a>
            <a href="logout.php" class="btn btn-danger">logout</a>
        </div>
    </nav>


    <div class="penjumlahan container mt-5">
        <div class="card">
            <div class="card-body">
                <form action="" method="POST">
                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <label for="exampleFormControlSelect1">Pilih Nama</label>
                                <select class="form-control" id="exampleFormControlSelect1" name="milih">
                                    <?php foreach ($product as $value) : ?>
                                        <option value="<?= $value["id"]; ?>"><?= $value["name"]; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col">
                            <div class="row">
                                <div class="col-md">
                                    <input type="number" value="1" name="isinyaTambah" class="form-control">
                                    <button class="btn btn-primary" name="tambah" type="submit">Tambah</button>
                                </div>
                                <div class="col-md">
                                    <input type="number" value="1" name="isinyaKurang" class="form-control">
                                    <button class="btn btn-primary" name="kurang" type="submit">Kurang</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="container mt-5">
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Name</th>
                    <th scope="col">Stock</th>
                    <th scope="col">Sold</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($product as $buka) : ?>
                    <tr>
                        <th scope="row"><?= $buka["id"]; ?></th>
                        <td><?= $buka["name"]; ?></td>
                        <td><?= $buka["stock"]; ?></td>
                        <td><?= $buka["sold"]; ?></td>
                        <td>
                            <form action="" method="POST">
                                <input type="hidden" name="id" value="<?= $buka["id"]; ?>">
                                <button class="btn btn-primary" name="pilih" value="ubah">ubah</button>
                                <button class="btn btn-danger" name="pilih" value="hapus">hapus</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <tr>
                    <th scope="col"></th>
                    <th scope="col"></th>
                    <th scope="col"></th>
                    <th scope="col"></th>
                    <th scope="col"><a href="tambah.php" class="btn btn-primary">Tambah</a></th>
                </tr>
            </tbody>
        </table>
    </div>


    <footer class="footer py-3 bg-light" style="margin-top: 400px;">
        <div class="container">
            <span class="text-muted">Place sticky footer content here.</span>
        </div>
    </footer>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
</body>

</html>