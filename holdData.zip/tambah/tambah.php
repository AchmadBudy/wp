<?php
session_start();

if (!isset($_SESSION["login"])) {
    header("Location: index.php");
    exit;
}
// var_dump($_GET);
require 'function.php';


$pro = query("SELECT * FROM template WHERE id = 1")[0]["desk"];
// var_dump($pro);

if (isset($_POST["tambah"])) {

    // cek apakah data berhasil di tambahkan atau tidak
    if (tambah($_POST) > 0) {
        echo "
			<script>
				alert('data berhasil ditambahkan!');
				document.location.href = 'tambah.php';
			</script>
		";
    } else {
        echo "
			<script>
				alert('data gagal ditambahkan!');
				document.location.href = 'tambah.php';
			</script>
		";
    }
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous" />
    <link href="https://fonts.googleapis.com/css2?family=Fredoka+One&display=swap" rel="stylesheet" />

    <style>
        .titled {
            font-family: "Fredoka One", cursive;
        }
    </style>

    <link rel="icon" href="../img/logoWB.png" />
    <title>AchticToserba</title>
</head>

<body>
    <nav class="navbar navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand titled" href="dashboard.php">
                <img src="../img/logoWB.png" width="30" height="30" class="d-inline-block align-top rounded" alt="" loading="lazy" />
                AchticToserba
            </a>
        </div>
    </nav>


    <div class="sale-content mt-5">
        <div class="container">
            <div class="row row-cols-1 row-cols-md-3">
                <div class="col mb-4">
                    <div class="card kotak">
                        <div class="card-body">
                            <form enctype="multipart/form-data" method="POST" action="">
                                <h3>Test pak</h3>
                                <div class="form-group">
                                    <label for="nama">nama produk</label>
                                    <input type="text" class="form-control" id="nama" name="nama">
                                </div>
                                <div class="form-group">
                                    <label for="nama">harga</label>
                                    <input type="number" class="form-control" id="nama" name="harga">
                                </div>
                                <div class="form-group">
                                    <label for="nama">Stock</label>
                                    <input type="number" class="form-control" id="nama" name="stock">
                                </div>
                                <div class="form-group">
                                    <label for="nama">Wa</label>
                                    <input type="text" class="form-control" id="nama" name="wa">
                                </div>
                                <div class="form-group">
                                    <label for="nama">Shopee</label>
                                    <input type="text" class="form-control" id="nama" name="shopee">
                                </div>
                                <div class="form-group">
                                    <label for="nama">gambar</label>
                                    <input type="file" class="form-control" id="nama" name="gambar">
                                </div>
                                <div class="form-group">
                                    <label for="desc">desc</label>
                                    <textarea id="desc" name="desc" rows="4" cols="50" class="form-control"><?= $pro ?></textarea>
                                </div>
                                <button type="submit" class="btn btn-primary" name="tambah">Submit</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <footer class="footer mt-auto py-3 bg-light">
        <div class="container">
            <span class="text-muted">Place sticky footer content here.</span>
        </div>
    </footer>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
</body>

</html>